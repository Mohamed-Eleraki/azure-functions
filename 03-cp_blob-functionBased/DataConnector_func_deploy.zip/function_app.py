"""cp Blob - DataConnect Project

The is the main entry point for cp Blob Azure function for the DataConnect project.
It is triggered by a blob InputStream event in the source container. Then, Starts manage
file transfer based on Data Catalog CSV file composed of the source and destination paths,
as well as SAS credentials provided.

The Function built on the Azure Functions Python SDK. The Function source-code following
Python PEP standards. it's code is well-documented, and function based with clear separation
of concerns i.e. check the utils folder for the helper functions.

the function is designed to be modular and reusable, allowing for easy integration and
future enhancements with other components of the DataConnect project.

For future enhancements, Please remember "a function do one thing only and do it well".

Examples:
This example provides how end users can use the function to manage file transefer to/from blobs.
for more info check the cp Blob DataConnect project documentation.

Copy a blob from source to destination:

- Open Azure portal, Navigate to the Storage account to which source directory you wanna copy from.

- On the right three dots, copy the URL of the source directory, Past it at data_catalog.csv file
under  the full_source_path column into dobule quotes.

- On the right three dots of the source directory, generate a SAS token, past the SAS token into the
data_catalog.csv file, consider place "?" before i.e. for source directoy the
least privilege is Read.

- Do the same for the Destination directory, but this time you need to generate a SAS token with
Write, create, delete, owner, and list permissions.

- Save.

- Upload a file to the source directory, this will trigger the function and copy the file to the
destination directory.logging.info("Extracted blob name: %s", blob_name)
logging.info("Updated source paths: %s", updated_src_paths)
logging.info("Updated destination paths: %s", updated_dest_paths)
try:
    cp_blob(updated_src_paths, updated_dest_paths)
    logging.info("Blob copied successfully")
except Exception as e:
    logging.error("Error copying blob: %s", str(e))
"""

# import os
import logging
# from azure.storage.blob import BlobClient, BlobServiceClient
import azure.functions as func
# from utils.cp_blob import cp_blob
# from utils.csv_reader import csv_dest_path_handler, csv_reader, csv_src_path_handler
# from cp_blob import cp_blob
# from csv_reader import csv_dest_path_handler, csv_reader, csv_src_path_handler

app = func.FunctionApp()
@app.blob_trigger(arg_name="myblob",
                  path="source",
                  connection="AzureWebJobsStorage"
                  )
def data_connector_cp_blob(myblob: func.InputStream) -> None:
    """data_connector_cp_blob function.

    This is the main entry point for cp Blob Azure function for the DataConnect project.
    It is triggered by a blob InputStream event in the source container. Then, Starts manage
    file transfer based on Data Catalog CSV file composed of the source and destination paths,
    as well as SAS credentials provided.

    Args:
        myblob (func.InputStream): Auto past aurg based on the trigger path.

    Returns:
        None: The function does not return any value.
    """

    # logging.info(
    #     "Python blob trigger function processed blob. "
    #     "Name: %s. Blob Size: %s bytes.",
    #     myblob.name,
    #     myblob.length,
    # )

    logging.info(f"Python blob trigger function processed blob"
                f"Name: {myblob.name}"
                f"Blob Size: {myblob.length} bytes")

    # Extract blob name (strip off container prefix)
    blob_name = myblob.name.split("/")[-1]
    print(blob_name)
    logging.info(f"Extracted blob name: {blob_name}")

    # Call the CSV reader function to get source and destination paths
    # paths_list = csv_reader()

    # Call the CSV source paths
    # updated_src_paths = csv_src_path_handler(paths_list, blob_name)

    # Call teh CSV destination paths
    # updated_dest_paths = csv_dest_path_handler(paths_list, blob_name)

    # Call the cp_blob function to copy the blob
    # connection_string = os.environ["AzureWebJobsStorage"]
    # src_container_name = myblob.name.split("/")[-0]
    # cp_blob(updated_src_paths, updated_dest_paths, connection_string, src_container_name, blob_name)
    # cp_blob(updated_src_paths, updated_dest_paths)
 
 
 
 
 
 
 
 
    
    # blb = myblob.name.replace("source/sourcedir01/", "")
    # connect_str = os.environ["AzureWebJobsStorage"]
    # connection_name = "source"
    
    # blob_service_client = BlobServiceClient.from_connection_string(connect_str)
    # container_client = blob_service_client.get_container_client(connection_name)
    # blob_client = container_client.get_blob_client(blb)
    # stream = blob_client.download_blob()
    # stream.readall()
    