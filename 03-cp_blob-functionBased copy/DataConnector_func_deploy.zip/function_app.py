"""cp Blob - DataConnect Project

The is the main entry point for cp Blob Azure function for the DataConnect project.
It is triggered by a blob InputStream event in the source container. Then, Starts manage
file transfer based on Data Catalog CSV file composed of the source and destination paths,
as well as SAS credentials provided.

The Function built on the Azure Functions Python SDK. The Function source-code following
Python PEP standards. it's code is well-documented, and function based with clear separation
of concerns i.e. check the utils folder for the helper functions.

the function is designed to be modular and reusable, allowing for easy integration and
future enhancements with other components of the DataConnect project.

For future enhancements, Please remember "a function do one thing only and do it well".

Examples:
This example provides how end users can use the function to manage file transefer to/from blobs.
for more info check the cp Blob DataConnect project documentation.

Copy a blob from source to destination:

- Open Azure portal, Navigate to the Storage account to which source directory you wanna copy from.

- On the right three dots, copy the URL of the source directory, Past it at data_catalog.csv file
under  the full_source_path column into dobule quotes.

- On the right three dots of the source directory, generate a SAS token, past the SAS token into the
data_catalog.csv file, consider place "?" before i.e. for source directoy the
least privilege is Read.

- Do the same for the Destination directory, but this time you need to generate a SAS token with
Write, create, delete, owner, and list permissions.

- Save.

- Upload a file to the source directory, this will trigger the function and copy the file to the
destination directory.logging.info("Extracted blob name: %s", blob_name)
logging.info("Updated source paths: %s", updated_src_paths)
logging.info("Updated destination paths: %s", updated_dest_paths)
try:
    cp_blob(updated_src_paths, updated_dest_paths)
    logging.info("Blob copied successfully")
except Exception as e:
    logging.error("Error copying blob: %s", str(e))
"""

import logging
import csv
import os
import azure.functions as func
from azure.storage.blob import BlobClient
# from utils.cp_blob import cp_blob
# from utils.csv_reader import csv_dest_path_handler, csv_reader, csv_src_path_handler
# from cp_blob import cp_blob
# from csv_reader import csv_dest_path_handler, csv_reader, csv_src_path_handler

app = func.FunctionApp()
@app.blob_trigger(
    arg_name="myblob", path="source/{name}", connection="AzureWebJobsStorage"
)
def data_connector_cp_blob(myblob: func.InputStream) -> None:
    """data_connector_cp_blob function.

    This is the main entry point for cp Blob Azure function for the DataConnect project.
    It is triggered by a blob InputStream event in the source container. Then, Starts manage
    file transfer based on Data Catalog CSV file composed of the source and destination paths,
    as well as SAS credentials provided.

    Args:
        myblob (func.InputStream): Auto past aurg based on the trigger path.

    Returns:
        None: The function does not return any value.
    """

    logging.info(
        "Python blob trigger function processed blob. "
        "Name: %s. Blob Size: %s bytes.",
        myblob.name,
        myblob.length,
    )

    # Extract blob name (strip off container prefix)
    blob_name = myblob.name.split("/")[-1]

    # Call the CSV reader function to get source and destination paths
    # paths_list = csv_reader()

    # Call the CSV source paths
    # updated_src_paths = csv_src_path_handler(paths_list, blob_name)

    # Call teh CSV destination paths
    # updated_dest_paths = csv_dest_path_handler(paths_list, blob_name)





    # csv_path = os.path.join(os.path.dirname(__file__), "../data_catalog.csv")
    # paths_list = []

    # try:
    #     with open(csv_path, "r", newline='', encoding="utf-8") as csvfile:
    #         reader = csv.DictReader(csvfile)
    #         for row in reader:
    #             paths_list.append({
    #                 "src_path": row["full_source_path"],
    #                 "src_sas" : row["src_sas"],
    #                 "dest_path" : row["full_dest_path"],
    #                 "dest_sas" : row["dest_sas"]
    #             })
    # except FileNotFoundError:
    #     print(f"File not found: {csv_path}")
    # except csv.Error as e:
    #     print(f"Error reading CSV file: {e}")
    # # return paths_list

    paths_list = [
        {
            "src_path": "https://filetransferintstorage.blob.core.windows.net/source/sourcedir01/*",
            "src_sas": "?sp=rawlme&st=2025-05-19T11:45:12Z&se=2025-06-15T19:45:12Z&spr=https&sv=2024-11-04&sr=c&sig=qMA5pPXoZIvjHlvitKRwyVt09ineFrNvXPB9eX5yRN4%3D",
            "dest_path": "https://filetransferintstorage.blob.core.windows.net/destination/destdir01/$BLOB_NAME",
            "dest_sas": "?sp=racwdlmeop&st=2025-05-19T11:52:35Z&se=2025-06-15T19:52:35Z&sv=2024-11-04&sr=c&sig=C80YBfRiQdOCXJI8KpgAyMYxyeDdxwuXzkbMbNUan6Y%3D"
        },
        {
            "src_path": "https://filetransferintstorage.blob.core.windows.net/source/sourcedir2/*",
            "src_sas": "?sp=r&st=2025-05-20T08:24:00Z&se=2025-06-15T16:24:00Z&spr=https&sv=2024-11-04&sr=d&sig=SMqYildy5IrI%2B0pgVAQyrLmve%2BVCfVtugpzUDl2lk7Y%3D&sdd=1",
            "dest_path": "https://filetransferintstorage.blob.core.windows.net/destination/destdir02/$BLOB_NAME",
            "dest_sas": "?sp=racwdlmeop&st=2025-05-20T08:22:45Z&se=2025-06-15T16:22:45Z&spr=https&sv=2024-11-04&sr=d&sig=ScTAUHEZBvU%2ByBAbneQbBe3%2FdfD5Nu%2BCQTTViekTLnY%3D&sdd=1"
        }
    ]


    updated_src_paths = []
    for path in paths_list:
        src_path = path["src_path"]
        src_sas = path["src_sas"]

        if "*" in src_path:
            src_path = src_path.replace("*", blob_name)

        src_path = src_path + src_sas
        updated_src_paths.append(src_path)
        continue
    # return updated_src_paths



    updated_dest_paths = []
    for path in paths_list:
        dest_path = path["dest_path"]
        dest_sas = path["dest_sas"]
        if "$BLOB_NAME" in dest_path:
            dest_path = dest_path.replace("$BLOB_NAME", blob_name)
        dest_path = dest_path + dest_sas

        updated_dest_paths.append(dest_path)
        continue
    # return updated_dest_paths



    # Call the cp_blob function to copy the blob
    # cp_blob(updated_src_paths, updated_dest_paths)


    for src_path, dest_path in zip(updated_src_paths, updated_dest_paths):
        try:
            logging.info(
                "Source Path: %s, Destination Path: %s.",
                src_path,
                dest_path,)

            dest_blob_client = BlobClient.from_blob_url(dest_path)

            # Get the source blob client full URL
            src_blob_client = BlobClient.from_blob_url(src_path)

            if src_blob_client.exists():
                copy_props = dest_blob_client.start_copy_from_url(src_path)
                logging.info("copy started. copy ID %s.", copy_props['copy_id'])
                continue
            else:
                logging.warning("Source blob does not exist: %s", src_path)

            logging.info("copy started. copy ID %s", copy_props['copy_id'])

        except Exception as e:
            logging.error("An error occurred while copying the blob: %s", e)
